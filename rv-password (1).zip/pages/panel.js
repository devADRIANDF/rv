import Head from "next/head";
import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import Nav from "../components/Nav";

export default function Panel() {
  const [user, setUser] = useState(null);
  const [stats, setStats] = useState(null);
  const [pedidos, setPedidos] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const router = useRouter();

  useEffect(() => {
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((d) => {
        if (!d.user) return router.replace("/login");
        setUser(d.user);
        Promise.all([
          fetch("/api/referidos/stats").then((r) => r.json()).catch(() => ({})),
          fetch("/api/pedidos/mios").then((r) => r.json()).catch(() => ({ pedidos: [] })),
        ]).then(([s, p]) => {
          setStats(s);
          setPedidos(Array.isArray(p?.pedidos) ? p.pedidos : []);
          setLoaded(true);
        });
      })
      .catch(() => router.replace("/login"));
  }, [router]);

  if (!loaded) {
    return (
      <>
        <Nav />
        <main className="min-h-screen bg-page px-5 py-16 text-sm text-mist">Cargando tu perfil…</main>
      </>
    );
  }

  // Variables seguras con fallbacks
  const referralCode = stats?.referral_code || stats?.referralCode || stats?.code || "";
  const referralLink =
    typeof window !== "undefined" && referralCode
      ? `${window.location.origin}/registro?ref=${referralCode}`
      : "";

  const totalReferidos = stats?.total_referidos ?? stats?.totalReferrals ?? stats?.referralsCount ?? 0;
  const totalGanadoCents = stats?.total_ganado_cents ?? (stats?.totalEarnings ? stats.totalEarnings * 100 : 0);
  const walletBalance = user?.wallet_balance ?? user?.balance ?? 0;

  // Garantizar que historial sea siempre un Array (evita el crash por .length)
  const historial = Array.isArray(stats?.historial)
    ? stats.historial
    : Array.isArray(stats?.earnings)
    ? stats.earnings
    : Array.isArray(stats?.history)
    ? stats.history
    : [];

  const userEmail = user?.email || "Usuario";
  const userInitial = userEmail[0]?.toUpperCase() || "U";

  return (
    <>
      <Head>
        <title>Tu perfil — ReviewVault</title>
      </Head>
      <Nav />
      <main className="min-h-screen bg-page pb-28 md:pb-10">
        <div className="mx-auto max-w-4xl px-5 py-8">
          <div className="flex items-center gap-4">
            <span className="flex h-14 w-14 items-center justify-center rounded-full bg-tealSoft font-display text-xl font-700 text-tealDark">
              {userInitial}
            </span>
            <div>
              <p className="font-display text-lg font-700 text-ink">{userEmail}</p>
              <p className="text-xs text-mist">Miembro de ReviewVault</p>
            </div>
          </div>

          <div className="mt-8 grid gap-3 sm:grid-cols-3">
            <div className="rounded-2xl border border-line bg-surface p-5">
              <p className="text-xs font-500 text-mist">Saldo del monedero</p>
              <p className="mt-2 font-display text-2xl font-700 text-teal">
                {(walletBalance / 100).toFixed(2)} €
              </p>
            </div>
            <div className="rounded-2xl border border-line bg-surface p-5">
              <p className="text-xs font-500 text-mist">Personas invitadas</p>
              <p className="mt-2 font-display text-2xl font-700 text-ink">{totalReferidos}</p>
            </div>
            <div className="rounded-2xl border border-line bg-surface p-5">
              <p className="text-xs font-500 text-mist">Ganado en comisiones</p>
              <p className="mt-2 font-display text-2xl font-700 text-ink">
                {(totalGanadoCents / 100).toFixed(2)} €
              </p>
            </div>
          </div>

          <div className="mt-6 rounded-2xl border border-line bg-surface p-5">
            <p className="text-xs font-600 uppercase tracking-wide text-mist">Tu enlace para invitar</p>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <code className="flex-1 truncate rounded-xl border border-line bg-page px-3 py-2 text-xs text-ink">
                {referralLink || "No disponible"}
              </code>
              <button
                onClick={() => referralLink && navigator.clipboard.writeText(referralLink)}
                className="rounded-full border border-line px-4 py-2 text-xs font-600 text-ink hover:border-teal hover:text-teal"
              >
                Copiar enlace
              </button>
            </div>
            <p className="mt-2 text-xs text-mist">
              Código {referralCode} · ganas el 10% de cada compra de quien invites
            </p>
          </div>

          <div className="mt-8">
            <p className="text-xs font-600 uppercase tracking-wide text-mist">Tus pedidos</p>
            <div className="mt-3 overflow-hidden rounded-2xl border border-line bg-surface">
              {pedidos.length === 0 ? (
                <p className="px-5 py-8 text-sm text-mist">Aún no has hecho ningún pedido.</p>
              ) : (
                pedidos.map((p) => (
                  <div
                    key={p.id}
                    className="flex items-center justify-between border-b border-line px-5 py-3 last:border-0"
                  >
                    <div>
                      <p className="text-sm text-ink">
                        {p.type === "cuenta" ? "Cuenta lista" : "Reviews a tu ID"} · {p.package} reviews
                        {p.target_id ? ` · ID ${p.target_id}` : ""}
                      </p>
                      <p className="text-xs text-mist">{new Date(p.created_at).toLocaleString("es-ES")}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-600 text-ink">{(p.amount_cents / 100).toFixed(2)} €</p>
                      <span
                        className={`rounded-full px-2 py-0.5 text-[11px] font-600 capitalize ${
                          p.status === "entregado"
                            ? "bg-tealSoft text-tealDark"
                            : p.status === "cancelado"
                            ? "bg-red-100 text-red-600"
                            : "bg-amber-100 text-amber-700"
                        }`}
                      >
                        {p.status}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="mt-8">
            <p className="text-xs font-600 uppercase tracking-wide text-mist">Historial de comisiones</p>
            <div className="mt-3 overflow-hidden rounded-2xl border border-line bg-surface">
              {historial.length === 0 ? (
                <p className="px-5 py-8 text-sm text-mist">
                  Aún no tienes comisiones. Comparte tu enlace para empezar a ganar.
                </p>
              ) : (
                historial.map((h, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between border-b border-line px-5 py-3 last:border-0"
                  >
                    <span className="text-sm text-ink">{h.from_email || h.email || "Usuario invitado"}</span>
                    <span className="text-sm font-600 text-teal">
                      +{((h.amount_cents || h.amount || 0) / 100).toFixed(2)} €
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          <CambiarPassword />

          <button
            onClick={async () => {
              await fetch("/api/auth/logout", { method: "POST" });
              router.push("/");
            }}
            className="mt-8 text-xs font-500 text-mist hover:text-ink"
          >
            Cerrar sesión
          </button>
        </div>
      </main>
    </>
  );
}
function CambiarPassword() {
  const [actual, setActual] = useState("");
  const [nueva, setNueva] = useState("");
  const [msg, setMsg] = useState(null); // { ok, texto }

  async function onSubmit(e) {
    e.preventDefault();
    setMsg(null);
    const r = await fetch("/api/auth/cambiar-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ current_password: actual, new_password: nueva }),
    });
    const data = await r.json().catch(() => ({}));
    if (r.ok) {
      setMsg({ ok: true, texto: "Contraseña actualizada." });
      setActual("");
      setNueva("");
    } else {
      setMsg({ ok: false, texto: data.error || "No se pudo cambiar la contraseña." });
    }
  }

  return (
    <div className="mt-8">
      <p className="text-xs font-600 uppercase tracking-wide text-mist">Cambiar contraseña</p>
      <form onSubmit={onSubmit} className="mt-3 grid gap-3 rounded-2xl border border-line bg-surface p-5 sm:grid-cols-3">
        <input type="password" value={actual} onChange={(e) => setActual(e.target.value)} required placeholder="Contraseña actual"
          className="rounded-xl border border-line bg-page px-4 py-2.5 text-sm text-ink outline-none focus:border-ink" />
        <input type="password" value={nueva} onChange={(e) => setNueva(e.target.value)} required minLength={6} placeholder="Nueva contraseña (mín. 6)"
          className="rounded-xl border border-line bg-page px-4 py-2.5 text-sm text-ink outline-none focus:border-ink" />
        <button type="submit" className="rounded-full border border-line px-4 py-2.5 text-sm font-600 text-ink hover:border-ink">
          Guardar contraseña
        </button>
        {msg && <p className={`text-xs sm:col-span-3 ${msg.ok ? "text-ink" : "text-red-600"}`}>{msg.texto}</p>}
      </form>
    </div>
  );
}
